@echo off
cd /d "%~dp0"
if not exist .env (
  copy .env.example .env
  echo Edit .env and replace WEBUI_SECRET_KEY with a long random secret.
  pause
  exit /b 1
)
docker compose up -d
echo.
echo NOVA AI website: http://localhost:3000
pause
