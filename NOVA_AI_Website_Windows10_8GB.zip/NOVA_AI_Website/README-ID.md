# NOVA AI Website — Windows 10 / RAM 8 GB

Paket website AI lokal: Open WebUI + Ollama. Tidak memerlukan API key AI berbayar.
Website dan chat berjalan di komputer sendiri; HP dapat mengaksesnya melalui Wi-Fi rumah.

## Rekomendasi untuk komputer 8 GB RAM
- Mulai hanya dengan model teks `qwen2.5:1.5b` (unduhan sekitar 986 MB).
- `Modelfile` membatasi konteks ke 2048 token agar pemakaian RAM lebih rendah.
- Gunakan satu model pada satu waktu. Tutup aplikasi berat saat AI berjalan.
- Jangan pasang model vision 3B dulu: file model Qwen2.5-VL 3B sekitar 3.2 GB dan pemakaian RAM saat inferensi lebih besar. Pada RAM 8 GB berpotensi membuat Windows berat.
- Model Qwen 1.5B lebih ringan tetapi kemampuan jawabannya terbatas dibanding model besar.

## 0. Periksa Windows
Docker Desktop saat ini mensyaratkan Windows 10 64-bit versi 22H2/build 19045 untuk konfigurasi WSL 2 yang didukung, WSL 2, virtualisasi BIOS aktif, dan minimal 8 GB RAM. Jika Windows bukan 22H2 atau Docker Desktop tidak kompatibel, opsi lebih ringan adalah menjalankan Open WebUI melalui Python atau memakai Linux.
Windows 10 telah melewati akhir dukungan umum Microsoft; pertimbangkan upgrade OS bila perangkat mendukung.

## 1. Instal komponen
1. Instal Ollama: https://ollama.com/download
2. Instal Docker Desktop: https://www.docker.com/products/docker-desktop/
3. Aktifkan WSL 2 dan virtualisasi CPU di BIOS/UEFI bila diminta.
4. Restart komputer setelah instalasi.

## 2. Unduh model ringan
Buka PowerShell:
```powershell
ollama pull qwen2.5:1.5b
```
Ekstrak folder proyek ini. Jalankan `install-model.bat` untuk membuat model `nova-qwen` dengan context lebih kecil. Atau jalankan:
```powershell
ollama create nova-qwen -f Modelfile
```

Untuk membatasi jumlah model yang aktif, buka PowerShell sebagai pengguna biasa:
```powershell
setx OLLAMA_MAX_LOADED_MODELS 1
setx OLLAMA_NUM_PARALLEL 1
```
Keluar dari Ollama dari system tray, lalu jalankan kembali Ollama agar pengaturan berlaku.

## 3. Atur secret
Salin `.env.example` menjadi `.env`. Ganti nilai `WEBUI_SECRET_KEY` dengan string acak panjang. Contoh PowerShell:
```powershell
-join ((1..64 | ForEach-Object { '{0:x}' -f (Get-Random -Maximum 16) }))
```
Tempel hasilnya setelah `WEBUI_SECRET_KEY=`. Jangan membagikan file `.env`.

## 4. Jalankan website
Pastikan Docker Desktop sudah Running. Klik dua kali `start-nova.bat`.
Buka:
- Komputer: http://localhost:3000
- Buat akun admin pertama saat halaman setup tampil.
- Pilih model `nova-qwen` di pemilih model.

Jika model tidak muncul, cek Ollama:
```powershell
ollama list
```
Lalu buka Admin Settings > Connections dan pastikan Ollama terhubung ke:
`http://host.docker.internal:11434`

## 5. Akses dari HP melalui Wi-Fi rumah
1. Komputer dan HP harus tersambung ke router Wi-Fi yang sama.
2. Di komputer, buka CMD dan jalankan `ipconfig`.
3. Catat IPv4 Address adaptor Wi-Fi, misalnya `192.168.1.20`.
4. Dari HP buka `http://192.168.1.20:3000`.
5. Jika tidak tersambung, izinkan Docker Desktop/Open WebUI pada Windows Firewall untuk jaringan Private. Jangan mematikan firewall.

## 6. Fitur
- Chat: pilih `nova-qwen`.
- Dokumen: unggah PDF/TXT/DOCX melalui tombol lampiran. Ekstraksi dan tanya-jawab dokumen memakai RAM tambahan; mulai dari file kecil.
- Memori: riwayat chat tersimpan di volume Docker `nova-data`. Fitur Memory tersendiri bergantung pada versi Open WebUI dan dapat diaktifkan di Settings bila tersedia.
- Pencarian web: Admin Settings > Web Search > Enable. Pilih DuckDuckGo bila tersedia. Ini memakai internet dan mengirim kueri ke penyedia pencarian, tetapi tidak membutuhkan API key.
- Voice: buka Admin Settings > Audio. Aktifkan engine yang tersedia. Beberapa fitur suara dapat mengunduh model tambahan dan meningkatkan pemakaian RAM; aktifkan belakangan, satu fitur pada satu waktu.
- Analisis gambar: untuk RAM 8 GB, jangan aktifkan model vision 3B sebagai default. Jika ingin menguji, unduh `ollama pull qwen2.5vl:3b`, tutup model/aplikasi lain, lalu uji satu gambar kecil. Jika sistem kehabisan RAM, hapus model dengan `ollama rm qwen2.5vl:3b`.

## Perawatan
```powershell
docker compose ps
docker compose logs -f open-webui
docker compose down
docker compose up -d
docker compose pull
docker compose up -d
```
`docker compose down -v` akan menghapus volume dan seluruh data NOVA AI. Jangan jalankan kecuali memang ingin menghapus semua chat dan konfigurasi.

## Keamanan
- Paket ini ditujukan untuk jaringan rumah/LAN, bukan internet publik.
- Jangan port-forward port 3000 atau 11434 di router.
- Untuk akses luar rumah, gunakan VPN pribadi seperti Tailscale/WireGuard dan autentikasi kuat.
- Komputer harus tetap menyala agar website dapat diakses.
- Backup volume `nova-data` secara berkala.

## Dokumentasi resmi
- Open WebUI Quick Start: https://docs.openwebui.com/getting-started/quick-start/
- Ollama: https://ollama.com/download
- Qwen2.5 model: https://ollama.com/library/qwen2.5
- Qwen2.5-VL: https://ollama.com/library/qwen2.5vl
- Docker Windows install: https://docs.docker.com/desktop/setup/install/windows-install/
