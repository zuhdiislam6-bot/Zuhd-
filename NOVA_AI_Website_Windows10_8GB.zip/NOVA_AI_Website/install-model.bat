@echo off
echo Downloading compact text model...
ollama pull qwen2.5:1.5b
echo Creating NOVA AI model with a smaller context window...
ollama create nova-qwen -f Modelfile
echo.
echo Done. Select nova-qwen in NOVA AI.
pause
